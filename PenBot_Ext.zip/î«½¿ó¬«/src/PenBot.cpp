#include "Arduino.h"
#include "PenBot.h"
#include "Sonar.h"
#include "pitches.h"

#include "stdio.h"

// prascaler bytes
byte PS_16 = (1 << ADPS2);
//byte PS_32 = (1 << ADPS2) | (1 << ADPS0);
//byte PS_64 = (1 << ADPS2) | (1 << ADPS1);
byte PS_128 = (1 << ADPS2) | (1 << ADPS1) | (1 << ADPS0);

/*
  //==========================================
  PenBot::PenBot() {

  Distance(PWM, SERVO);

  pinMode(M1_A, OUTPUT);
  pinMode(M1_B, OUTPUT);
  pinMode(M1_C, OUTPUT);
  pinMode(M1_D, OUTPUT);

  pinMode(M2_A, OUTPUT);
  pinMode(M2_B, OUTPUT);
  pinMode(M2_C, OUTPUT);
  pinMode(M2_D, OUTPUT);

  pinMode(LED1, OUTPUT);
  pinMode(LED2, OUTPUT);

  // --- Входове ---
  pinMode(BUT1, INPUT);
  pinMode(BUT2, INPUT);
  pinMode(IR, INPUT);

  //------ Servo ----------
  pen.attach(SERVO);
  pen.write(PEN_UP);

  }
*/


//////////////////////////////////////////////////
void PenBot::begin() {
  // set sample rate to XXXX X001 => 16 micros readings
  ADCSRA &= ~PS_128;
  ADCSRA |= PS_16;

  tone(BEEP, 2000, 80);
  delay(130);
  tone(BEEP, 2700, 80);
  delay(130);
  tone(BEEP, 2940, 80);
  delay(130);
  penUp();
  gripperOpen();
}


void PenBot::penAttach(void) {
  //------ Servo ----------
  pen.attach(SERVO);
  pen.write(PEN_UP);
}

void PenBot::servoAttach(void) {
  gripper.attach(SERVO2);
  gripper.write(GRIPPER_OPEN);
}


//////////////////////////////////////////////////
void PenBot::moveForward(int disatance) {
  steps = (disatance * 22);
  speed = START_SPEED;

  if (steps < RAMP * 2)
    ramp = steps / 2;
  else
    ramp = RAMP;

  start_ramp = (START_SPEED - MAX_SPEED) / RAMP;
  stop_ramp = (STOP_SPEED - MAX_SPEED) / RAMP;;
  starting = true;

  while (steps > 0) {

    if (++current_left_step > 7)
      current_left_step = 0;

    if (++current_right_step > 7)
      current_right_step = 0;

    PORTD = (PORTD & B11000011) | M1_steps[current_left_step];
    PORTB = (PORTB & B11110000) | M2_steps[current_right_step];

    delayMicroseconds(speed);
    steps--;
    if (steps > RAMP) {
      if ((speed >= MAX_SPEED)) {
        speed -= start_ramp;
      }
    } else {
      if ( speed < STOP_SPEED) {
        speed += stop_ramp;
      }
    }

  }
  delay(60);
}

//////////////////////////////////////////
void PenBot::moveBack(int disatance) {

  steps = (disatance * 22);
  speed = START_SPEED;

  if (steps < RAMP * 2)
    ramp = steps / 2;
  else
    ramp = RAMP;

  start_ramp = (START_SPEED - MAX_SPEED) / RAMP;
  stop_ramp = (STOP_SPEED - MAX_SPEED) / RAMP;;
  starting = true;

  while (steps > 0) {

    if (current_right_step )
      current_right_step--;
    else
      current_right_step = 7;

    if (current_left_step )
      current_left_step--;
    else
      current_left_step = 7;

    PORTD = (PORTD & B11000011) | M1_steps[current_left_step];
    PORTB = (PORTB & B11110000) | M2_steps[current_right_step];

    delayMicroseconds(speed);
    steps--;

    if (steps > RAMP) {
      if ((speed >= MAX_SPEED)) {
        speed -= start_ramp;
      }
    } else {
      if ( speed < STOP_SPEED) {
        speed += stop_ramp;
      }
    }
  }
  delay(60);
}

///////////////////////////////////////
void PenBot::stepForward() {

  if (++current_left_step > 7)
    current_left_step = 0;

  if (++current_right_step > 7)
    current_right_step = 0;

  PORTD = (PORTD & B11000011) | M1_steps[current_left_step];
  PORTB = (PORTB & B11110000) | M2_steps[current_right_step];

  delayMicroseconds(MAX_SPEED);

  if (++current_left_step > 7)
    current_left_step = 0;

  if (++current_right_step > 7)
    current_right_step = 0;

  PORTD = (PORTD & B11000011) | M1_steps[current_left_step];
  PORTB = (PORTB & B11110000) | M2_steps[current_right_step];
  delayMicroseconds(MAX_SPEED);
}

//////////////////////////////////////////
void PenBot::stepBackward() {

  if (current_right_step )
    current_right_step--;
  else
    current_right_step = 7;

  if (current_left_step )
    current_left_step--;
  else
    current_left_step = 7;

  PORTD = (PORTD & B11000011) | M1_steps[current_left_step];
  PORTB = (PORTB & B11110000) | M2_steps[current_right_step];

  delayMicroseconds(MAX_SPEED);

  if (current_right_step )
    current_right_step--;
  else
    current_right_step = 7;

  if (current_left_step )
    current_left_step--;
  else
    current_left_step = 7;

  PORTD = (PORTD & B11000011) | M1_steps[current_left_step];
  PORTB = (PORTB & B11110000) | M2_steps[current_right_step];
  delayMicroseconds(MAX_SPEED);

}



//////////////////////////////////////////
void PenBot::stepRight() {

  if (++current_right_step > 7)
    current_right_step = 0;

  if (current_left_step )
    current_left_step--;
  else
    current_left_step = 7;

  PORTD = (PORTD & B11000011) | M1_steps[current_left_step];
  PORTB = (PORTB & B11110000) | M2_steps[current_right_step];

  delayMicroseconds(MAX_SPEED);

  if (++current_right_step > 7)
    current_right_step = 0;

  if (current_left_step )
    current_left_step--;
  else
    current_left_step = 7;

  PORTD = (PORTD & B11000011) | M1_steps[current_left_step];
  PORTB = (PORTB & B11110000) | M2_steps[current_right_step];
}


//////////////////////////////////////////
void PenBot::stepLeft() {

  if (current_right_step )
    current_right_step--;
  else
    current_right_step = 7;

  if (++current_left_step > 7)
    current_left_step = 0;

  PORTD = (PORTD & B11000011) | M1_steps[current_left_step];
  PORTB = (PORTB & B11110000) | M2_steps[current_right_step];

  delayMicroseconds(MAX_SPEED);

  if (current_right_step )
    current_right_step--;
  else
    current_right_step = 7;

  if (++current_left_step > 7)
    current_left_step = 0;

  PORTD = (PORTD & B11000011) | M1_steps[current_left_step];
  PORTB = (PORTB & B11110000) | M2_steps[current_right_step];
}


//////////////////////////////////////////
void PenBot::leftMotorStep () {

  if (++current_right_step > 7)
    current_right_step = 0;
  PORTB = (PORTB & B11110000) | M2_steps[current_right_step];
  delayMicroseconds(MAX_SPEED);

  if (++current_right_step > 7)
    current_right_step = 0;
  PORTB = (PORTB & B11110000) | M2_steps[current_right_step];
  delayMicroseconds(MAX_SPEED);
}


//////////////////////////////////////////
void PenBot::rightMotorStep() {

  if (++current_left_step > 7)
    current_left_step = 0;
  PORTD = (PORTD & B11000011) | M1_steps[current_left_step];
  delayMicroseconds(MAX_SPEED);

  if (++current_left_step > 7)
    current_left_step = 0;
  PORTD = (PORTD & B11000011) | M1_steps[current_left_step];
  delayMicroseconds(MAX_SPEED);
}

//////////////////////////////
void PenBot::stop()
{
  digitalWrite(M1_A, LOW);
  digitalWrite(M1_B, LOW);
  digitalWrite(M1_C, LOW);
  digitalWrite(M1_D, LOW);

  digitalWrite(M2_A, LOW);
  digitalWrite(M2_B, LOW);
  digitalWrite(M2_C, LOW);
  digitalWrite(M2_D, LOW);

  //pen.detach();
}


///////////////////////////////

void PenBot::turnLeft(int degrees) {
  steps = 360 / degrees;
  steps = TURN_STEPS_360 / steps;

  speed = START_SPEED;

  if (steps < RAMP * 2)
    ramp = steps / 2;
  else
    ramp = RAMP;

  start_ramp = (START_SPEED - MAX_SPEED) / RAMP;
  stop_ramp = (STOP_SPEED - MAX_SPEED) / RAMP;;
  starting = true;

  while (steps > 0) {
    if (++current_left_step > 7)
      current_left_step = 0;

    if (current_right_step )
      current_right_step--;
    else
      current_right_step = 7;

    PORTD = (PORTD & B11000011) | M1_steps[current_left_step];
    PORTB = (PORTB & B11110000) | M2_steps[current_right_step];

    delayMicroseconds(speed);
    steps--;

    if (steps > ramp) {
      if ((speed >= MAX_SPEED)) {
        speed -= start_ramp;
      }
    } else {
      if ( speed < STOP_SPEED) {
        speed += stop_ramp;
      }

    }
  }

  delay(60);
}



/////////////////////
void PenBot::turnRight(int degrees) {

  steps = 360 / degrees;
  steps = TURN_STEPS_360 / steps;

  speed = START_SPEED;

  if (steps < RAMP * 2)
    ramp = steps / 2;
  else
    ramp = RAMP;

  start_ramp = (START_SPEED - MAX_SPEED) / RAMP;
  stop_ramp = (STOP_SPEED - MAX_SPEED) / RAMP;;
  starting = true;

  while (steps > 0) {
    if (++current_right_step > 7)
      current_right_step = 0;

    if (current_left_step )
      current_left_step--;
    else
      current_left_step = 7;

    PORTD = (PORTD & B11000011) | M1_steps[current_left_step];
    PORTB = (PORTB & B11110000) | M2_steps[current_right_step];

    delayMicroseconds(speed);
    steps--;

    if (steps > RAMP) {
      if ((speed >= MAX_SPEED)) {
        speed -= start_ramp;
      }
    } else {
      if ( speed < STOP_SPEED) {
        speed += stop_ramp;
      }
    }
  }

  delay(60);
}

///////////////////////////////////
int PenBot::readSonar() {
  int range = Distance.Ranging(CM);
  return range;
}



///////////////////////////////////
void PenBot::penUp() {
  pen.attach(SERVO);
  pen.write(PEN_UP);
  delay(500);
  pen.detach();
}

///////////////////////////////////
void PenBot::penDown() {
  pen.attach(SERVO);
  pen.write(PEN_DOWN);
  delay(500);
  pen.detach();
}

///////////////////////////////////
void PenBot::gripperOpen() {
  gripper.attach(SERVO2);
  gripper.write(GRIPPER_OPEN);
  delay(500);
  gripper.detach();
}

///////////////////////////////////
void PenBot::gripperClose() {
  gripper.attach(SERVO2);
  gripper.write(GRIPPER_CLOSE);
  delay(500);
}

///////////////////////////////////PenBot::song
void PenBot::gripperPosition(int pos) {
  int angle;
  gripper.attach(SERVO2);
  angle = map(pos, 0, 100, GRIPPER_CLOSE, GRIPPER_OPEN);
  gripper.write(angle);
  delay(200);
}



////////////////////////////////////
void PenBot::setRedLed(char value) {
  digitalWrite(LED2, value);
}

////////////////////////////////////
void PenBot::setGreenLed(char value) {
  digitalWrite(LED1, value);
}




//--------------------------------
void PenBot::song(char mm) {
  int noteDuration;
  int thisNote;
  const int *notes;
  const int *notesDurations;
  char song_length;

  switch (mm) {
    case 0:
      notes = melody;               // Mario
      notesDurations = noteDurations;
      song_length = sizeof(melody) / 2;

      break;
    case 1:
      notes = mario_melody;         //Mario main theme
      notesDurations = mario_tempo;
      song_length = sizeof(mario_melody) / 2;
      break;
    case 2:
      notes = underworld_melody;         //Mario main theme
      notesDurations = underworld_tempo;
      song_length = sizeof(underworld_melody) / 2;
      break;
    case 3:
      notes = melody1;                //Melody 1 - Marry Had a Little Lamb
      notesDurations = noteDurations1;
      song_length = sizeof(melody1) / 2;
      break;
    case 4:
      notes = melody2;                //Melody 2 - The Itsy Bitsy Spider
      notesDurations = noteDurations2;
      song_length = sizeof(melody2) / 2;
      break;

  }

  // ---  Изпълняване на мелодията ---
  for ( thisNote = 0; thisNote < song_length; thisNote++) {
    // to calculate the note duration, take one second
    // divided by the note type. //e.g. quarter note = 1000 / 4, eighth note = 1000/8, etc.
    noteDuration = 1000 / notesDurations[thisNote];
    tone(BEEP, notes[thisNote], noteDuration);
    // to distinguish the notes, set a minimum time between them.
    // the note's duration + 30% seems to work well:
    int pauseBetweenNotes = noteDuration * 1.30;
    delay(pauseBetweenNotes);
    // stop the tone playing:
    noTone(BEEP);
  }
}


/////////////////////////////////////////////////////////////////////////////////
char tmp_str[64];
//===============================  CALIBRATE ======================================
//-------------------
void PenBot::callibrate(void) {
  int i, sens1, sens2;
  int sensor_value1, sensor_value2;
  unsigned int tmp_value;

  //--- Preset the arrays ---
  sensor_calmin1 = 4095;    // Maximum ADC value
  sensor_calmin2 = 4095;    // Maximum ADC value
  sensor_calmax1 = 0;     // Minimum ADC value
  sensor_calmax1 = 0;     // Minimum ADC value

  digitalWrite( OPT_ENABLE , HIGH);
  delayMicroseconds(500);

  //--- Turn right ---
  for (i = 0; i < 600; i++) {
    //----- Find minimum and maximum values for all sensors -----
    tmp_value = analogRead(LINE_SENSOR1) / 2;
    if (tmp_value < sensor_calmin1)
      sensor_calmin1 = tmp_value;
    if (tmp_value > sensor_calmax1)
      sensor_calmax1 = tmp_value;

    tmp_value = analogRead(LINE_SENSOR2) / 2;
    if (tmp_value < sensor_calmin2)
      sensor_calmin2 = tmp_value;
    if (tmp_value > sensor_calmax2)
      sensor_calmax2 = tmp_value;

    stepRight();
    delayMicroseconds(AQUIRE_SPEED);

  }

  //--- Turn left ---
  for (i = 0; i < 1100; i++) {
    //----- Find minimum and maximum values for all sensors -----
    tmp_value = analogRead(LINE_SENSOR1) / 2;
    if (tmp_value < sensor_calmin1)
      sensor_calmin1 = tmp_value;
    if (tmp_value > sensor_calmax1)
      sensor_calmax1 = tmp_value;

    tmp_value = analogRead(LINE_SENSOR2) / 2;
    if (tmp_value < sensor_calmin2)
      sensor_calmin2 = tmp_value;
    if (tmp_value > sensor_calmax2)
      sensor_calmax2 = tmp_value;

    stepLeft();
    delayMicroseconds(AQUIRE_SPEED);
  }


  //digitalWrite( OPT_ENABLE , LOW);
  //stop();
  delay(1000);

  //-------   Calculate calibration  denom --------
  sensor_denom1 = ( sensor_calmax1 - sensor_calmin1 ) / 10;
  sensor_denom2 = ( sensor_calmax2 - sensor_calmin2 ) / 10;

  sprintf(tmp_str, " min1 %d - max1 %d", sensor_calmin1, sensor_calmax1);
  Serial.println(tmp_str);
  sprintf(tmp_str, " min2 %d - max2 %d", sensor_calmin2, sensor_calmax2);
  Serial.println(tmp_str);

  //---------- Go back to the line ----------
  do {
    sensor_value1 = read_leftSensor();      // Left sensor scaled value
    sensor_value2 = read_rightSensor();     // Left sensor scaled value
    stepRight();
    delayMicroseconds(AQUIRE_SPEED);
  }
  while ( !((sensor_value1 > 20) && (sensor_value2 > 20))); //&& (sensor_value1 / 2 == sensor_value2 / 2)));

  sprintf(tmp_str, " left  %d - right %d", sensor_value1, sensor_value2);
  Serial.println(tmp_str);


  // --- Stop the motors ---
  //stop();

  digitalWrite( OPT_ENABLE, LOW);
  Serial.print("ready");
}

//============================= Read sensors  and scale =====================
char PenBot::read_leftSensor(void) {
  int sens1, sensor_value;

  digitalWrite( OPT_ENABLE , HIGH);
  delayMicroseconds(350);

  sens1 = analogRead( LINE_SENSOR1) / 2;
  digitalWrite( OPT_ENABLE, LOW);
  if (sens1 > sensor_calmin1)
    sensor_value = ((sens1 - sensor_calmin1) * 10) / sensor_denom1;// Left sensor scaled value
  else
    sensor_value = 0;
  return (char) sensor_value;
}

char PenBot::read_rightSensor(void) {
  int sens1, sensor_value;

  digitalWrite( OPT_ENABLE , HIGH);
  delayMicroseconds(350);

  sens1 = analogRead( LINE_SENSOR2) / 2;
  digitalWrite( OPT_ENABLE, LOW);
  if (sens1 > sensor_calmin1)
    sensor_value = ((sens1 - sensor_calmin1) * 10) / sensor_denom1;// Left sensor scaled value
  else
    sensor_value = 0;
  return (char) sensor_value;
}


