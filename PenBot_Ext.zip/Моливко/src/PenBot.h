/*
  Class for PenBot platform



*/
#ifndef PenBot_H_
#define PenBot_H_

#include "Arduino.h"
#include "stdint.h"
#include "Servo.h"
#include "Sonar.h"
#include "pitches.h"

#include <avr/pgmspace.h>





///////////////////////////////////////////////////////////
//-------------------------- Pin Definitions --------------
#define M1_A    2     // PD2
#define M1_B    3     // PD3
#define M1_C    4     // PD4
#define M1_D    5     // PD5

#define M2_A    11    // PB3
#define M2_B    10    // PB2
#define M2_C    9    // PB1
#define M2_D    8    // PB0

#define LED1    A3
#define LED2    A4    //PC4 - 22

#define PWM     6
#define SERVO   6

#define BEEP    13


#define TRIG    12
#define ECHO    7

#define BUT1    A1
#define BUT2    A0

#define LINE_SENSOR1    A6      // ADC6
#define LINE_SENSOR2    A7      // ADC7
#define OPT_ENABLE      A2      // PC2

#define IO1             A4
#define IO2             A5
#define SERVO2          A5


///////////////////////////////////////////////////////////
//-------------   STEPS Definitions --------------
/*
#define TURN_STEPS_360  3260

#define MAX_SPEED   2000
#define START_SPEED 3600
#define STOP_SPEED  4000
#define RAMP        120    // steps
#define AQUIRE_SPEED  2600
*/

#define TURN_STEPS_360          6588   
#define TURN_STEPS_PER_DEGREE   183          //  (TURN_STEPS_360*10)/360 

#define MAX_SPEED   850        //780     //  860
#define START_SPEED 3000
#define STOP_SPEED  2000
#define RAMP        220    // steps
#define AQUIRE_SPEED  1500

#define PEN_DOWN  170
#define PEN_UP    80

#define GRIPPER_OPEN  100
#define GRIPPER_CLOSE 178

////////////////////////////////////////////////////////
/*
unsigned char const M1_steps[8] = { B000100, B001000, B010000, B100000, B000100, B001000, B010000, B100000 };            
unsigned char const M2_steps[8] = { B0001, B0010, B0100, B1000, B0001, B0010, B0100, B1000 };
                                     */

unsigned char const M1_steps[8] = {   B100100, B000100, B001100, B001000, B011000, B010000, B110000, B100000  };
unsigned char const M2_steps[8] = {  B0001, B0011, B0010, B0110, B0100, B1100, B1000, B1001};
                                     

//-------------- Songs -------------
//-------------- Songs -------------
const int  melody[8] = { NOTE_C7, NOTE_G6, NOTE_G6, NOTE_A6, NOTE_G6, 0, NOTE_B6, NOTE_C7 };
// note durations: 4 = quarter note, 8 = eighth note, etc.:
const int noteDurations[8] = { 4, 8, 8, 4, 4, 4, 4, 4 };


//Melody 1 - Marry Had a Little Lamb
// notes in the melody (see notes.h)
const int  melody1[] = {
  NOTE_E4, NOTE_D4, NOTE_C4, NOTE_D4, NOTE_E4, NOTE_E4, NOTE_E4,
  NOTE_D4, NOTE_D4, NOTE_D4, NOTE_E4, NOTE_E4, NOTE_E4,
  NOTE_E4, NOTE_D4, NOTE_C4, NOTE_D4, NOTE_E4, NOTE_E4, NOTE_E4,
  NOTE_D4, NOTE_D4, NOTE_D4, NOTE_E4, NOTE_D4, NOTE_C4,
};
// note durations: 4 = quarter note, 8 = eighth note, etc.:
const int noteDurations1[] = {
  4, 4, 4, 4, 4, 4, 2,
  4, 4, 2, 4, 4, 2,
  4, 4, 4, 4, 4, 4, 2,
  4, 4, 2, 4, 4, 2
};

//Melody 2 - The Itsy Bitsy Spider
// notes in the melody (see notes.h)
const int melody2[] = {
  NOTE_G3, NOTE_C4, NOTE_C4, NOTE_C4, NOTE_D4, NOTE_E4, NOTE_E4,
  NOTE_E4, NOTE_D4, NOTE_C4, NOTE_D4, NOTE_E4, NOTE_C4, 0,
  NOTE_E4, NOTE_E4, NOTE_F4, NOTE_G4,
  NOTE_G4, NOTE_F4, NOTE_E4, NOTE_F4, NOTE_G4, NOTE_E4, 0,
  NOTE_C4, NOTE_C4, NOTE_D4, NOTE_E4,
  NOTE_E4, NOTE_D4, NOTE_C4, NOTE_D4, NOTE_E4, NOTE_C4, 0,
  NOTE_G3, NOTE_G3, NOTE_C4, NOTE_C4, NOTE_C4, NOTE_D4, NOTE_E4, NOTE_E4,
  NOTE_E4, NOTE_D4, NOTE_C4, NOTE_D4, NOTE_E4, NOTE_C4
};
// note durations: 4 = quarter note, 8 = eighth note, etc.:
const int noteDurations2[] = {
  4, 4, 4, 4, 4, 2, 2,
  4, 4, 4, 4, 4, 4, 2,
  2, 4, 4, 2,
  2, 4, 4, 4, 4, 4, 2,
  2, 4, 4, 2,
  2, 4, 4, 4, 4, 4, 2,
  4, 4, 4, 4, 4, 4, 2, 2,
  4, 4, 4, 4, 4, 2
};


//-----------------------------------------------------------------------
#define REST 0

//---------------------------------------------------------------
//Mario main theme melody
const int mario_melody[] = {
  NOTE_E7, NOTE_E7, 0, NOTE_E7,
  0, NOTE_C7, NOTE_E7, 0,
  NOTE_G7, 0, 0,  0,
  NOTE_G6, 0, 0, 0,

  NOTE_C7, 0, 0, NOTE_G6,
  0, 0, NOTE_E6, 0,
  0, NOTE_A6, 0, NOTE_B6,
  0, NOTE_AS6, NOTE_A6, 0,

  NOTE_G6, NOTE_E7, NOTE_G7,
  NOTE_A7, 0, NOTE_F7, NOTE_G7,
  0, NOTE_E7, 0, NOTE_C7,
  NOTE_D7, NOTE_B6, 0, 0,

  NOTE_C7, 0, 0, NOTE_G6,
  0, 0, NOTE_E6, 0,
  0, NOTE_A6, 0, NOTE_B6,
  0, NOTE_AS6, NOTE_A6, 0,

  NOTE_G6, NOTE_E7, NOTE_G7,
  NOTE_A7, 0, NOTE_F7, NOTE_G7,
  0, NOTE_E7, 0, NOTE_C7,
  NOTE_D7, NOTE_B6
};

//Mario main them tempo
const int mario_tempo[] = {
  12, 12, 12, 12,
  12, 12, 12, 12,
  12, 12, 12, 12,
  12, 12, 12, 12,

  12, 12, 12, 12,
  12, 12, 12, 12,
  12, 12, 12, 12,
  12, 12, 12, 12,

  9, 9, 9,
  12, 12, 12, 12,
  12, 12, 12, 12,
  12, 12, 12, 12,

  12, 12, 12, 12,
  12, 12, 12, 12,
  12, 12, 12, 12,
  12, 12, 12, 12,

  9, 9, 9,
  12, 12, 12, 12,
  12, 12, 12, 12,
  12, 12
};

//------------------------------------------------------------
//Underworld melody
const int underworld_melody[] = {
  NOTE_C4, NOTE_C5, NOTE_A3, NOTE_A4,
  NOTE_AS3, NOTE_AS4, 0,
  0,
  NOTE_C4, NOTE_C5, NOTE_A3, NOTE_A4,
  NOTE_AS3, NOTE_AS4, 0,
  0,
  NOTE_F3, NOTE_F4, NOTE_D3, NOTE_D4,
  NOTE_DS3, NOTE_DS4, 0,
  0,
  NOTE_F3, NOTE_F4, NOTE_D3, NOTE_D4,
  NOTE_DS3, NOTE_DS4, 0,
  0, NOTE_DS4, NOTE_CS4, NOTE_D4,
  NOTE_CS4, NOTE_DS4,
  NOTE_DS4, NOTE_GS3,
  NOTE_G3, NOTE_CS4,
  NOTE_C4, NOTE_FS4, NOTE_F4, NOTE_E3, NOTE_AS4, NOTE_A4,
  NOTE_GS4, NOTE_DS4, NOTE_B3,
  NOTE_AS3, NOTE_A3, NOTE_GS3
};

//Underwolrd tempo
const  int  underworld_tempo[] = {
  12, 12, 12, 12,
  12, 12, 6,
  3,
  12, 12, 12, 12,
  12, 12, 6,
  3,
  12, 12, 12, 12,
  12, 12, 6,
  3,
  12, 12, 12, 12,
  12, 12, 6,
  6, 18, 18, 18,
  6, 6,
  6, 6,
  6, 6,
  18, 18, 18, 18, 18, 18,
  10, 10, 10,
  10, 10, 10
};



///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
class PenBot //: public SoftwareSerial
{ //: public EasyMotor
  public:
      PenBot(): Distance(TRIG, ECHO) {

      pinMode(M1_A, OUTPUT);
      pinMode(M1_B, OUTPUT);
      pinMode(M1_C, OUTPUT);
      pinMode(M1_D, OUTPUT);

      pinMode(M2_A, OUTPUT);
      pinMode(M2_B, OUTPUT);
      pinMode(M2_C, OUTPUT);
      pinMode(M2_D, OUTPUT);

      pinMode(LED1, OUTPUT);
      pinMode(LED2, OUTPUT);

      pinMode(BEEP, OUTPUT);

      // --- Входове ---
      pinMode(BUT1, INPUT);
      pinMode(BUT2, INPUT);

      //------ Sonar ----------
      pinMode(TRIG, OUTPUT);
      pinMode(ECHO, INPUT);

      //------ IR line sensors ----
     // pinMode(LINE_SENSOR1, INPUT);
      //pinMode(LINE_SENSOR2, INPUT);
      pinMode(OPT_ENABLE, OUTPUT);
      digitalWrite(OPT_ENABLE, LOW);      // PC2


    }

    void begin();                          // set Robot Head to Center, looking to front,
    void moveForward(int distance);        // move forward function,
    void moveBack(int distance);            //
    void stop();                            // stop the robot     
    void turnRight(int degrees);           // turn to the right   
    void turnLeft(int degrees);            //turn robot to the left

    void stepForward();
    void stepBackward();
    void stepLeft();
    void stepRight();
    void rightMotorStep ();
    void leftMotorStep();

    int readSonar();                 ///read the distance 
    int readButtons();

    void setGreenLed( char value);
    void setRedLed(char value);

    void penAttach(void);
    void penUp(void);
    void penDown();

   void servoAttach(void);
    void gripperOpen(void);
    void gripperClose();
    void gripperPosition(int pos);

    void callibrate(void);
    char read_leftSensor(void); 
    char read_rightSensor(void); 

    void song(char mm);

  private:
    Sonar Distance;
    Servo pen;
    Servo gripper;

    //=================  CALIBRATE ==========================
    unsigned int sensor_values1;
    unsigned int sensor_calmin1;
    unsigned int sensor_calmax1;
    unsigned int sensor_denom1;
    //----
    unsigned int sensor_values2;
    unsigned int sensor_calmin2;
    unsigned int sensor_calmax2;
    unsigned int sensor_denom2;
    
    //-------
    unsigned char current_left_step;
    unsigned char current_right_step;
    unsigned int speed;

    unsigned int steps;
    unsigned int ramp;
    unsigned int start_ramp;
    unsigned int stop_ramp;
    boolean starting;

};


//extern SoftwareSerial BT(BT_RX_Pin,BT_TX_Pin);
#endif
//////////////////////////////////////
