/*
  Class for DrawBot platform



*/
#ifndef DRAWBOT_H_
#define DRAWBOT_H_

#include "Arduino.h"
#include "stdint.h"
#include "Servo.h"
#include "Sonar.h"
#include "pitches.h"

#include <avr/pgmspace.h>

///////////////////////////////////////////////////////////
//-------------------------- Pin Definitions --------------
#define M1_A    2     // PD2
#define M1_B    3     // PD3
#define M1_C    4     // PD4
#define M1_D    5     // PD5

#define M2_A    A0    // PC0
#define M2_B    A1    // PC1
#define M2_C    A2    // PC2
#define M2_D    A3    // PC3

#define LED1    7
#define LED2    22    //A4    //PC4 - 22

#define PWM     6
#define SERVO   6

#define BEEP    13


#define TRIG    12
#define ECHO    11

#define BUT1     9
#define BUT2    10


#define IR      8


///////////////////////////////////////////////////////////

//-------------   STEPS Definitions --------------
//-------------   STEPS Definitions --------------
/*
  #define TURN_STEPS_360  1944

  #define MAX_SPEED   1200
  #define STOP_SPEED  4000
  #define RAMP        220    // steps

  #define PEN_DOWN  130
  #define PEN_UP    85

  #define GRIPPER_OPEN	120
  #define GRIPPER_CLOSE	179

  ////////////////////////////////////////////////////////
  unsigned char const M1_steps[8] = {   B100000, B110000, B010000, B011000, B001000, B001100, B000100, B100100 };
  unsigned char const M2_steps[8] = {  B0001, B0011, B0010, B0110, B0100, B1100, B1000, B1001};
*/


#define TURN_STEPS_360  972
#define LUFT_ERROR   0

#define MAX_SPEED   3500
#define START_SPEED 8000
#define STOP_SPEED  7000
#define RAMP        80    // steps

#define PEN_DOWN  140
#define PEN_UP    65

#define GRIPPER_OPEN  120
#define GRIPPER_CLOSE 179

////////////////////////////////////////////////////////
unsigned char const M1_steps[8] = {   B100000, B010000, B001000, B000100, B100000, B010000, B001000, B000100 };
unsigned char const M2_steps[8] = {  B0001, B0010, B0100, B1000, B0001, B0010, B0100, B1000 };


//-------------- Songs -------------
//-------------- Songs -------------
const int  melody[8] = { NOTE_C7, NOTE_G6, NOTE_G6, NOTE_A6, NOTE_G6, 0, NOTE_B6, NOTE_C7 };
// note durations: 4 = quarter note, 8 = eighth note, etc.:
const int noteDurations[8] = { 4, 8, 8, 4, 4, 4, 4, 4 };


//Melody 1 - Marry Had a Little Lamb
// notes in the melody (see notes.h)
const int  melody1[] = {
  NOTE_E4, NOTE_D4, NOTE_C4, NOTE_D4, NOTE_E4, NOTE_E4, NOTE_E4,
  NOTE_D4, NOTE_D4, NOTE_D4, NOTE_E4, NOTE_E4, NOTE_E4,
  NOTE_E4, NOTE_D4, NOTE_C4, NOTE_D4, NOTE_E4, NOTE_E4, NOTE_E4,
  NOTE_D4, NOTE_D4, NOTE_D4, NOTE_E4, NOTE_D4, NOTE_C4,
};
// note durations: 4 = quarter note, 8 = eighth note, etc.:
const int noteDurations1[] = {
  4, 4, 4, 4, 4, 4, 2,
  4, 4, 2, 4, 4, 2,
  4, 4, 4, 4, 4, 4, 2,
  4, 4, 2, 4, 4, 2
};

//Melody 2 - The Itsy Bitsy Spider
// notes in the melody (see notes.h)
const int melody2[] = {
  NOTE_G3, NOTE_C4, NOTE_C4, NOTE_C4, NOTE_D4, NOTE_E4, NOTE_E4,
  NOTE_E4, NOTE_D4, NOTE_C4, NOTE_D4, NOTE_E4, NOTE_C4, 0,
  NOTE_E4, NOTE_E4, NOTE_F4, NOTE_G4,
  NOTE_G4, NOTE_F4, NOTE_E4, NOTE_F4, NOTE_G4, NOTE_E4, 0,
  NOTE_C4, NOTE_C4, NOTE_D4, NOTE_E4,
  NOTE_E4, NOTE_D4, NOTE_C4, NOTE_D4, NOTE_E4, NOTE_C4, 0,
  NOTE_G3, NOTE_G3, NOTE_C4, NOTE_C4, NOTE_C4, NOTE_D4, NOTE_E4, NOTE_E4,
  NOTE_E4, NOTE_D4, NOTE_C4, NOTE_D4, NOTE_E4, NOTE_C4
};
// note durations: 4 = quarter note, 8 = eighth note, etc.:
const int noteDurations2[] = {
  4, 4, 4, 4, 4, 2, 2,
  4, 4, 4, 4, 4, 4, 2,
  2, 4, 4, 2,
  2, 4, 4, 4, 4, 4, 2,
  2, 4, 4, 2,
  2, 4, 4, 4, 4, 4, 2,
  4, 4, 4, 4, 4, 4, 2, 2,
  4, 4, 4, 4, 4, 2
};


//-----------------------------------------------------------------------
#define REST 0

//---------------------------------------------------------------
//Mario main theme melody
const int mario_melody[] = {
  NOTE_E7, NOTE_E7, 0, NOTE_E7,
  0, NOTE_C7, NOTE_E7, 0,
  NOTE_G7, 0, 0,  0,
  NOTE_G6, 0, 0, 0,

  NOTE_C7, 0, 0, NOTE_G6,
  0, 0, NOTE_E6, 0,
  0, NOTE_A6, 0, NOTE_B6,
  0, NOTE_AS6, NOTE_A6, 0,

  NOTE_G6, NOTE_E7, NOTE_G7,
  NOTE_A7, 0, NOTE_F7, NOTE_G7,
  0, NOTE_E7, 0, NOTE_C7,
  NOTE_D7, NOTE_B6, 0, 0,

  NOTE_C7, 0, 0, NOTE_G6,
  0, 0, NOTE_E6, 0,
  0, NOTE_A6, 0, NOTE_B6,
  0, NOTE_AS6, NOTE_A6, 0,

  NOTE_G6, NOTE_E7, NOTE_G7,
  NOTE_A7, 0, NOTE_F7, NOTE_G7,
  0, NOTE_E7, 0, NOTE_C7,
  NOTE_D7, NOTE_B6
};

//Mario main them tempo
const int mario_tempo[] = {
  12, 12, 12, 12,
  12, 12, 12, 12,
  12, 12, 12, 12,
  12, 12, 12, 12,

  12, 12, 12, 12,
  12, 12, 12, 12,
  12, 12, 12, 12,
  12, 12, 12, 12,

  9, 9, 9,
  12, 12, 12, 12,
  12, 12, 12, 12,
  12, 12, 12, 12,

  12, 12, 12, 12,
  12, 12, 12, 12,
  12, 12, 12, 12,
  12, 12, 12, 12,

  9, 9, 9,
  12, 12, 12, 12,
  12, 12, 12, 12,
  12, 12
};

//------------------------------------------------------------
//Underworld melody
const int underworld_melody[] = {
  NOTE_C4, NOTE_C5, NOTE_A3, NOTE_A4,
  NOTE_AS3, NOTE_AS4, 0,
  0,
  NOTE_C4, NOTE_C5, NOTE_A3, NOTE_A4,
  NOTE_AS3, NOTE_AS4, 0,
  0,
  NOTE_F3, NOTE_F4, NOTE_D3, NOTE_D4,
  NOTE_DS3, NOTE_DS4, 0,
  0,
  NOTE_F3, NOTE_F4, NOTE_D3, NOTE_D4,
  NOTE_DS3, NOTE_DS4, 0,
  0, NOTE_DS4, NOTE_CS4, NOTE_D4,
  NOTE_CS4, NOTE_DS4,
  NOTE_DS4, NOTE_GS3,
  NOTE_G3, NOTE_CS4,
  NOTE_C4, NOTE_FS4, NOTE_F4, NOTE_E3, NOTE_AS4, NOTE_A4,
  NOTE_GS4, NOTE_DS4, NOTE_B3,
  NOTE_AS3, NOTE_A3, NOTE_GS3
};

//Underwolrd tempo
const  int  underworld_tempo[] = {
  12, 12, 12, 12,
  12, 12, 6,
  3,
  12, 12, 12, 12,
  12, 12, 6,
  3,
  12, 12, 12, 12,
  12, 12, 6,
  3,
  12, 12, 12, 12,
  12, 12, 6,
  6, 18, 18, 18,
  6, 6,
  6, 6,
  6, 6,
  18, 18, 18, 18, 18, 18,
  10, 10, 10,
  10, 10, 10
};



///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
class DrawBot //: public SoftwareSerial
{ //: public EasyMotor
  public:

    //    DrawBot():  RightMotor(rightMotor_pinA,rightMotor_pinB), LeftMotor(leftMotor_pinA,leftMotor_pinB), Distance(SR04_Trig,SR04_Echo)//, BT(BT_RX_Pin,BT_TX_Pin)
    //	 {} //initializer list for objects using within this Class

    DrawBot(): Distance(TRIG, ECHO) {

      //DrawBot() {

      pinMode(M1_A, OUTPUT);
      pinMode(M1_B, OUTPUT);
      pinMode(M1_C, OUTPUT);
      pinMode(M1_D, OUTPUT);

      pinMode(M2_A, OUTPUT);
      pinMode(M2_B, OUTPUT);
      pinMode(M2_C, OUTPUT);
      pinMode(M2_D, OUTPUT);

      pinMode(LED1, OUTPUT);
      pinMode(LED2, OUTPUT);

      pinMode(BEEP, OUTPUT);

      // --- Входове ---
      pinMode(BUT1, INPUT);
      pinMode(BUT2, INPUT);
      pinMode(IR, INPUT);

      //------ Sonar ----------
      pinMode(TRIG, OUTPUT);
      pinMode(ECHO, INPUT);

    }
    
    void begin();                          // set Robot Head to Center, looking to front,
    void moveForward(int distance);           // move forward function, Hàm chạy thẳng
    void moveBack(int distance);            //
    void stop();             // stop the robot       || Hàm dừng robot
    void turnRight(int degrees);           // turn to the right   || Quay robot sang phải
    void turnLeft(int degrees);            //turn robot to the left || Quay robot sang trái
    void stepForward();
    void stepBackward();
    int readSonar();                 ///read the distance || Đọc khoảng cách ex: int khoangcach = robot.readSonar();
    int readButtons();

    void setGreenLed( char value);
    void setRedLed(char value);

    void penUp(void);
    void penDown();
    void gripperPosition(int pos);

    void gripperOpen(void);
    void gripperClose();


    void song(char mm);



  private:
    Sonar Distance;
    Servo pen;

    unsigned char current_left_step;
    unsigned char current_right_step;
    unsigned int speed;

    unsigned int steps;
    unsigned int ramp;
    unsigned int start_ramp;
    unsigned int stop_ramp;
    boolean starting;

};


//extern SoftwareSerial BT(BT_RX_Pin,BT_TX_Pin);
#endif
//////////////////////////////////////
