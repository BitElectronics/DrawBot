#include "Arduino.h"
#include "DrawBot.h"
#include "Sonar.h"
#include "pitches.h"

/*
  //==========================================
  DrawBot::DrawBot() {

  Distance(PWM, SERVO);

  pinMode(M1_A, OUTPUT);
  pinMode(M1_B, OUTPUT);
  pinMode(M1_C, OUTPUT);
  pinMode(M1_D, OUTPUT);

  pinMode(M2_A, OUTPUT);
  pinMode(M2_B, OUTPUT);
  pinMode(M2_C, OUTPUT);
  pinMode(M2_D, OUTPUT);

  pinMode(LED1, OUTPUT);
  pinMode(LED2, OUTPUT);

  // --- Входове ---
  pinMode(BUT1, INPUT);
  pinMode(BUT2, INPUT);
  pinMode(IR, INPUT);

  //------ Servo ----------
  pen.attach(SERVO);
  pen.write(PEN_UP);

  }
*/

void DrawBot::begin() {
  //------ Servo ----------
  pen.attach(SERVO);
  pen.write(PEN_UP);

}

//////////////////////////////////////////////////
void DrawBot::moveForward(int disatance) {
  steps = (disatance * 15);
  steps = steps / 4;
  steps = steps - disatance / 4;

  speed = START_SPEED;

  if (steps < RAMP * 2)
    ramp = steps / 2;
  else
    ramp = RAMP;

  start_ramp = (START_SPEED - MAX_SPEED) / RAMP;
  stop_ramp = (STOP_SPEED - MAX_SPEED) / RAMP;;
  starting = true;

  while (steps > 0) {

    if (++current_left_step > 7)
      current_left_step = 0;

    if (++current_right_step > 7)
      current_right_step = 0;

    PORTD = (PORTD & B11000011) | M1_steps[current_left_step];
    PORTC = (PORTC & B11110000) | M2_steps[current_right_step];

    delayMicroseconds(speed);
    steps--;
    if (steps > RAMP) {
      if ((speed >= MAX_SPEED)) {
        speed -= start_ramp;
      }
    } else {
      if ( speed < STOP_SPEED) {
        speed += stop_ramp;
      }
    }

  }
  delay(60);
}

//////////////////////////////////////////
void DrawBot::moveBack(int disatance) {

  steps = (disatance * 15);
  steps = steps / 4;
  steps = steps - disatance / 4;

  speed = START_SPEED;

  if (steps < RAMP * 2)
    ramp = steps / 2;
  else
    ramp = RAMP;

  start_ramp = (START_SPEED - MAX_SPEED) / RAMP;
  stop_ramp = (STOP_SPEED - MAX_SPEED) / RAMP;;
  starting = true;

  while (steps > 0) {

    if (current_right_step )
      current_right_step--;
    else
      current_right_step = 7;

    if (current_left_step )
      current_left_step--;
    else
      current_left_step = 7;

    PORTD = (PORTD & B11000011) | M1_steps[current_left_step];
    PORTC = (PORTC & B11110000) | M2_steps[current_right_step];

    delayMicroseconds(speed);
    steps--;

    if (steps > RAMP) {
      if ((speed >= MAX_SPEED)) {
        speed -= start_ramp;
      }
    } else {
      if ( speed < STOP_SPEED) {
        speed += stop_ramp;
      }
    }
  }
  delay(60);
}

///////////////////////////////////////
void DrawBot::stepForward() {

  if (++current_left_step > 7)
    current_left_step = 0;

  if (++current_right_step > 7)
    current_right_step = 0;

  PORTD = (PORTD & B11000011) | M1_steps[current_left_step];
  PORTC = (PORTC & B11110000) | M2_steps[current_right_step];
}

//////////////////////////////////////////
void DrawBot::stepBackward() {

  if (current_right_step )
    current_right_step--;
  else
    current_right_step = 7;

  if (current_left_step )
    current_left_step--;
  else
    current_left_step = 7;

  PORTD = (PORTD & B11000011) | M1_steps[current_left_step];
  PORTC = (PORTC & B11110000) | M2_steps[current_right_step];
}



//////////////////////////////
void DrawBot::stop()
{
  digitalWrite(M1_A, LOW);
  digitalWrite(M1_B, LOW);
  digitalWrite(M1_C, LOW);
  digitalWrite(M1_D, LOW);

  digitalWrite(M2_A, LOW);
  digitalWrite(M2_B, LOW);
  digitalWrite(M2_C, LOW);
  digitalWrite(M2_D, LOW);

  pen.detach();
}


///////////////////////////////

void DrawBot::turnRight(int degrees) {
  steps = 360 / degrees;
  steps = TURN_STEPS_360 / steps;

  speed = START_SPEED;

  if (steps < RAMP * 2)
    ramp = steps / 2;
  else
    ramp = RAMP;

  start_ramp = (START_SPEED - MAX_SPEED) / RAMP;
  stop_ramp = (STOP_SPEED - MAX_SPEED) / RAMP;;
  starting = true;

  while (steps > 0) {
    if (++current_left_step > 7)
      current_left_step = 0;

    if (current_right_step )
      current_right_step--;
    else
      current_right_step = 7;

    PORTD = (PORTD & B11000011) | M1_steps[current_left_step];
    PORTC = (PORTC & B11110000) | M2_steps[current_right_step];

    delayMicroseconds(speed);
    steps--;

    if (steps > ramp) {
      if ((speed >= MAX_SPEED)) {
        speed -= start_ramp;
      }
    } else {
      if ( speed < STOP_SPEED) {
        speed += stop_ramp;
      }

    }
  }

  delay(60);
}



/////////////////////
void DrawBot::turnLeft(int degrees) {

  steps = 360 / degrees;
  steps = TURN_STEPS_360 / steps;

  speed = START_SPEED;

  if (steps < RAMP * 2)
    ramp = steps / 2;
  else
    ramp = RAMP;

  start_ramp = (START_SPEED - MAX_SPEED) / RAMP;
  stop_ramp = (STOP_SPEED - MAX_SPEED) / RAMP;;
  starting = true;

  while (steps > 0) {
    if (++current_right_step > 7)
      current_right_step = 0;

    if (current_left_step )
      current_left_step--;
    else
      current_left_step = 7;

    PORTD = (PORTD & B11000011) | M1_steps[current_left_step];
    PORTC = (PORTC & B11110000) | M2_steps[current_right_step];

    delayMicroseconds(speed);
    steps--;

    if (steps > RAMP) {
      if ((speed >= MAX_SPEED)) {
        speed -= start_ramp;
      }
    } else {
      if ( speed < STOP_SPEED) {
        speed += stop_ramp;
      }
    }
  }

  delay(60);
}

///////////////////////////////////
int DrawBot::readSonar() {
  int range = Distance.Ranging(CM);
  return range;
}



///////////////////////////////////
void DrawBot::penUp() {
  pen.write(PEN_UP);
  delay(150);
}

///////////////////////////////////
void DrawBot::penDown() {
  pen.write(PEN_DOWN);
  delay(150);
}

///////////////////////////////////
void DrawBot::gripperOpen() {
  pen.write(GRIPPER_OPEN);
  delay(150);
}

///////////////////////////////////
void DrawBot::gripperClose() {
  pen.write(GRIPPER_CLOSE);
  delay(150);
}

///////////////////////////////////
void DrawBot::gripperPosition(int pos) {
  int angle;
  angle = map(pos, 0, 100, GRIPPER_CLOSE, GRIPPER_OPEN);
  pen.write(angle);
  delay(150);
}



////////////////////////////////////
void DrawBot::setRedLed(char value) {
  digitalWrite(LED2, value);
}

////////////////////////////////////
void DrawBot::setGreenLed(char value) {
  digitalWrite(LED1, value);
}




//--------------------------------
void DrawBot::song(char mm) {
  int noteDuration;
  int thisNote;
  const int *notes;
  const int *notesDurations;
  char song_length;

  switch (mm) {
    case 0:
      notes = melody;               // Mario
      notesDurations = noteDurations;
      song_length = sizeof(melody) / 2;

      break;
    case 1:
      notes = mario_melody;         //Mario main theme
      notesDurations = mario_tempo;
      song_length = sizeof(mario_melody) / 2;
      break;
    case 2:
      notes = underworld_melody;         //Mario main theme
      notesDurations = underworld_tempo;
      song_length = sizeof(underworld_melody) / 2;
      break;
    case 3:
      notes = melody1;                //Melody 1 - Marry Had a Little Lamb
      notesDurations = noteDurations1;
      song_length = sizeof(melody1) / 2;
      break;
    case 4:
      notes = melody2;                //Melody 2 - The Itsy Bitsy Spider
      notesDurations = noteDurations2;
      song_length = sizeof(melody2) / 2;
      break;

  }

  // ---  Изпълняване на мелодията ---
  for ( thisNote = 0; thisNote < song_length; thisNote++) {
    // to calculate the note duration, take one second
    // divided by the note type. //e.g. quarter note = 1000 / 4, eighth note = 1000/8, etc.
    noteDuration = 1000 / notesDurations[thisNote];
    tone(BEEP, notes[thisNote], noteDuration);
    // to distinguish the notes, set a minimum time between them.
    // the note's duration + 30% seems to work well:
    int pauseBetweenNotes = noteDuration * 1.30;
    delay(pauseBetweenNotes);
    // stop the tone playing:
    noTone(BEEP);
  }
}


/////////////////////////////////////////////////////////////////////////////////
/*
  //////////////////////////////////

  void Easybot::lookright()
  {

  Headservo.attach(Servo1_pin);
  Headservo.write(Right_angle);
  delay(500);
  Headservo.detach();//release for using PWM on Pin 9,10


  }

  //////
  void Easybot::lookleft()
  {

  Headservo.attach(Servo1_pin);
  Headservo.write(Left_angle);
  delay(500);
  Headservo.detach();//release for using PWM on Pin 9,10


  }
  ///
  void Easybot::lookfront()
  {

  Headservo.attach(Servo1_pin);
  Headservo.write(Center_angle);
  delay(500);
  Headservo.detach();//release for using PWM on Pin 9,10


  }

*/

